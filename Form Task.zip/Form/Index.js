import React, { useEffect, useState } from 'react'

const Container = () => {
    let [userData,setUserData]=useState({name:'',email:'',mobile:'',gender:'',jobs:'',ctc:'',skills:[]})
    let [finalData,setFinalData]=useState(()=>{
        let savedData=JSON.parse(localStorage.getItem('user'));
        if(savedData===null){
            // return [{name:'',email:'',mobile:'',gender:'',jobs:'',ctc:'',skills:[]}]
            return []
        }
        else{
            return savedData
        }
    })
    let handleSubmit=(e)=>{
        e.preventDefault();
        setFinalData([...finalData,userData])
        setUserData({name:'',email:'',mobile:'',gender:null,jobs:null,ctc:null,skills:[]})
        alert("successfull Submited")
    }
    let selectedSkill=(e)=>{
        let checked=e.target.checked
        if(checked){
            setUserData({...userData,skills:[...userData.skills,e.target.value]})
        }
        else{
           setUserData({...userData,skills: userData.skills.filter(data=>data!==e.target.value)})
        }
        console.log(userData.skills)
    }

    useEffect(()=>{
        localStorage.setItem('user',JSON.stringify(finalData))
    },[finalData])

  return (
    <form onSubmit={(e)=>handleSubmit(e)}  className=" container border  border-dark rounded w-25 p-3  mt-5 bg-secondary text-white shadow-lg p-3 mb-5 ">
       <div className='p-2'>
        <label>Name<span className="required ">*</span></label><br/>
        <input type="text" className='border border-dark rounded w-75 p-2' value={userData.name} placeholder='Enter Your Name' onChange={e=>setUserData({...userData,name:e.target.value})} />
       </div>
       <div className='p-2'>
        <label>Email<span className="required ">*</span></label><br/>
        <input type="email" className='border border-dark rounded w-75 p-2' value={userData.email} placeholder='Enter Your Email'onChange={e=>setUserData({...userData,email:e.target.value})} />
       </div>
       <div className='p-2'>
        <label>Mobile No<span className="required ">*</span></label><br/>
        <input type="text" className='border border-dark rounded w-75 p-2' value={userData.mobile} placeholder='Enter Your Mobile No.' onChange={e=>setUserData({...userData,mobile:e.target.value})} />
       </div>
       <div className='p-2'>
        <label>Gender<span className="required ">*</span></label><br/>
        <div className=' d-flex justify-content-between w-50'>
        <div>
        <input type="radio"  value='male' name='gender' onChange={e=>setUserData({...userData,gender:e.target.value})}/>Male
        </div>
       <div>
       <input  type="radio"  value='female' name='gender' onChange={e=>setUserData({...userData,gender:e.target.value})} />Female
       </div>
        </div>
       </div>
       <div className='p-2'>
        <label>Jobs<span className="required ">*</span></label><br/>
        <select className='border border-dark rounded w-75 p-2' onClick={e=>setUserData({...userData,jobs:e.target.value})}>
            <option value="" >--select--</option>
            <option value="Fullstack developer">Fullstack developer</option>
            <option value="Ui/Ux Developer">Ui/Ux Developer</option>
            <option value="Java Developer">Java Developer</option>
            <option value="Python Developer">Python Developer</option>
            <option value="Javascript Developer">Javascript Developer-</option>
        </select>
       </div>
       <div className='p-2'>
        <label>CTC<span className="required ">*</span></label><br/>
        <select className='border border-dark rounded w-75 p-2' onClick={e=>setUserData({...userData,ctc:e.target.value})}>
            <option value="">--select--</option>
            <option value="upto 1LPA">upto 1LPA</option>
            <option value="1LPA - 1.8LPA">1LPA - 1.8LPA</option>
            <option value="1.8LPA - 2LPA<">1.8LPA - 2LPA</option>
            <option value="2.1LPA - 3LPA">2.1LPA - 3LPA</option>
            <option value="3.1LPA - 4LPA">3.1LPA - 4LPA</option>
            <option value="4LPA+">4LPA+</option>
        </select>
       </div>
       <div className='p-2'>
        <label htmlFor="">Skills<span className="required ">*</span></label><br/>
       <div className='d-flex  flex-column  '>
       <div className='d-flex justify-content-between w-75 '>
       <input type="checkbox" value='React' onClick={(e)=>selectedSkill(e)} />React
        <input type="checkbox" value='Javascript'  onClick={(e)=>selectedSkill(e)} />Javascript
        <input type="checkbox" value='Java'  onClick={(e)=>selectedSkill(e)} />Java
       </div>
      <div className='d-flex justify-content-between w-75 '>
      <input type="checkbox" value='Python'  onClick={(e)=>selectedSkill(e)} />Python
        <input type="checkbox" value='Html'  onClick={(e)=>selectedSkill(e)} />HTML
        <input type="checkbox" value='Css'  onClick={(e)=>selectedSkill(e)} />Css
      </div>
       </div>
       </div>

       <div className='p-2 d-flex justify-content-center p-25 '>
        <button type='submit' className='border border-dark rounded bg-dark text-light'>Submit</button>
       </div>
    </form>
  )
}

export default Container