import React from "react";
import Tabledata from "../Tabledata/Index";
import Form from"../Form/Index"
function Container(){
    return(
        <div>
            <Form/>
            <Tabledata/>
        </div>
    )
}
export default Container