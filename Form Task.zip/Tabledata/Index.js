
import React, { useEffect, useState } from "react";
import "./Index.css"
const Input = () => {
  let [userData, setUserData] = useState({
  });
  let [isEdit, setEdit] = useState(false);
  let [newData, setNewData] = useState([]);

  useEffect(() => {
    setNewData(JSON.parse(localStorage.getItem("user")));
  }, []);
  useEffect(() => {
    localStorage.setItem("user", JSON.stringify(newData));
  }, [newData]);

  let handleDelete = (id) => {
    
    if(isEdit!==id){setNewData(newData.filter((el, index) => index !== id));}
    else{
        newData.reduce((acc,item,index)=>{
            if(index===id){
              return [...acc,{...item,...userData}]
            }
            return [...acc]
        },[])
    }
  };
  let selectedSkill=(e)=>{
        let checked=e.target.checked
        if(checked){
            if(userData.skills){
                setUserData({...userData,skills:[...userData.skills,e.target.value]})
            }
            else{
                setUserData({...userData,skills:[e.target.value]})
            }
            
        }
        else{
           setUserData({...userData,skills: userData.skills.filter(data=>data!==e.target.value)})
        }
        console.log(userData.skills)
    }
  let editData = (id) => {
    if(isEdit===false){
        setEdit(id)
        console.log('if '+isEdit)
    }
    else{
        setEdit(false)
        console.log('else '+isEdit)
    }
    
  };
  return (
    <table>
      <thead>
        <tr>
          <th>S.no.</th>
          <th>Name</th>
          <th>Email</th>
          <th>Mobile No.</th>
          <th>Gender</th>
          <th>Job</th>
          <th>Expected CTC</th>
          <th>Skills</th>
        </tr>
      </thead>
      <tbody>
        {newData.map((data, index) => {
          return (
            <tr key={index}>
              {isEdit === index ? (
                <>
                  <td>{index + 1}</td>
                  <td>
                    <input
                      type="text"
                      value={data.name}
                      onChange={(e) =>
                        setNewData({ ...userData, name: e.target.value })
                      }
                    />
                  </td>
                  <td>
                    <input
                      type="text"
                      value={data.email}
                      onChange={(e) =>
                        setNewData({ ...userData, email: e.target.value })
                      }
                    />
                  </td>
                  <td>
                    <input
                      type="text"
                      value={data.mobile}
                      onChange={(e) =>
                        setNewData({ ...userData, mobile: e.target.value })
                      }
                    />
                  </td>
                  <td>
                    <input
                      type="radio"
                      value="male"
                      name="gender"
                      onChange={(e) =>
                        setUserData({ ...userData, gender: e.target.value })
                      }
                    />
                    Male
                    <input
                      type="radio"
                      value="female"
                      name="gender"
                      onChange={(e) =>
                        setUserData({ ...userData, gender: e.target.value })
                      }
                    />
                    Female
                  </td>
                  <td>
                    <select
                      onClick={(e) =>
                        setUserData({ ...userData, jobs: e.target.value })
                      }
                    >
                      <option value="">--select--</option>
                      <option value="Fullstack developer">
                        Fullstack developer
                      </option>
                      <option value="Ui/Ux Developer">Ui/Ux Developer </option>
                      <option value="Java Developer">Java Developer </option>
                      <option value="Python Developer">Python Developer </option>
                      <option value="Javascript Developer">
                        Javascript Developer-
                      </option>
                    </select>
                  </td>
                  <td>
                    <select
                      onClick={(e) =>
                        setUserData({ ...userData, ctc: e.target.value })
                      }
                    >
                      <option value="">--select--</option>
                      <option value="upto 1LPA">upto 1LPA</option>
                      <option value="1LPA - 1.8LPA">1LPA - 1.8LPA</option>
                      <option value="1.8LPA - 2LPA<">1.8LPA - 2LPA</option>
                      <option value="2.1LPA - 3LPA">2.1LPA - 3LPA</option>
                      <option value="3.1LPA - 4LPA">3.1LPA - 4LPA</option>
                      <option value="4LPA+">4LPA+</option>
                    </select>
                  </td>
                  <td >
                    <input type="checkbox" value="React" onClick={(e) => selectedSkill(e)}/>React 
                    <input type="checkbox" value="Javascript" onClick={(e) => selectedSkill(e)}/>Javascript <br/>
                    <input type="checkbox" value="Java" onClick={(e) => selectedSkill(e)}/>Java 
                    <input type="checkbox" value="Python" onClick={(e) => selectedSkill(e)}/> Python <br/>
                    <input type="checkbox" value="Css" onClick={(e) => selectedSkill(e)}/>Css 
                    <input type="checkbox" value="Bootstrap" onClick={(e) => selectedSkill(e)}/>Bootstrap 
                    </td>
                  <td><button className=" border rounded" onClick={() => editData(index)}>{index === isEdit ? "Cancel" : "Edit"}</button></td>
                  <td>
                    <button className=" border rounded" onClick={() => handleDelete(index)}>{index === isEdit ? "Done" : "Delete"}</button>
                  </td>
                </>
              ) : (
                <>
                  <td>{index + 1}</td>
                  <td>{data.name}</td>
                  <td>{data.email}</td>
                  <td>{data.mobile}</td>
                  <td>{data.gender}</td>
                  <td>{data.jobs}</td>
                  <td>{data.ctc}</td>
                  <td>{data.skills}</td>
                  <td>
                    <button className=" border rounded" onClick={()=>editData(index)}>Edit</button>
                  </td>
                  <td>
                    <button className=" border rounded" onClick={() => {handleDelete(index);}}>Delete</button>
                  </td>
                </>
              )}
            </tr>
          );
        })}
      </tbody>
    </table>
  );
};

export default Input
